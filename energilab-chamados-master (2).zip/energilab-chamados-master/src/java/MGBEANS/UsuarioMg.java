/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MGBEANS;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.event.ActionEvent;

/**
 *
 * @author User
 */
 @ManagedBean(name = "cadastroUsuario")
public class UsuarioMg {
   

    private List<UsuarioEntity> listarUsuario;
    
    private UsuarioEntity categoria;

    @PostConstruct
    public void init(){
        
        listarUsuario = new ArrayList<UsuarioEntity>();
        
        listarUsuario.add(new UsuarioEntity("nome","Nome"));
        listarUsuario.add(new UsuarioEntity("matricula","Matricula"));
       listarUsuario.add(new UsuarioEntity("senha","Senha"));
        
    }
    
    public CadastroUsuarioBean(){
        Usuario = new UsuarioEntity();
    }

 

    public List<UsuarioEntity> getListarUsuario() {
        return listarUsuario;
    }

    public void setListarUsuario(List<UsuarioEntity> listarUsuario) {
        this.listarUsuario = listarUsuario;
    }

    public UsuarioEntity getUsuario() {
        return Usuario;
    }

    public void setUsuario(UsuarioEntity usu) {
        this.Usuario = usu;
    }
    
    public void limparForm(ActionEvent e){
        usuario = new UsuarioEntity();
    }
    
    public UsuarioEntity getUsuarioById(String id){
        
        for (UsuarioEntity u: listarUsuario){
            if (u.getId().equals(id)){
                return u;
            }
        }
        return null;
    }
    
}
    

