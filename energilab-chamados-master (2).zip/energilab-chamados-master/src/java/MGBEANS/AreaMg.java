/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MGBEANS;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

/**
 *
 * @author User
 */
@ManagedBean(name = "cadastroCurso")
@ViewScoped
public class AreaMg {

    private List<AreaEntity> listaArea;

    private AreaEntity Area;

    private String nome;

    public List<AreaEntity> getListaArea() {
        return listaArea;
    }

    public void setListaArea(List<AreaEntity> listaArea) {
        this.listaArea = listaArea;
    }

    public AreaEntity getArea() {
        return Area;
    }

    public void setArea(AreaEntity Area) {
        this.Area = Area;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public CadastroAreaBean() {
       
        this.listarAreasAtivas();
        area = new AreaEntity();
    }

    public void cadastrarArea() {

        try {

            AreaDAO dao = new AreaDAO();
            boolean ret = dao.inserirArea(area);

            if (ret) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_INFO, "SUCESSO!",
                                "Novo registro inserido no banco de dados."));
            } else {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                "Erro!", "O registro não foi inserido."));
            }

        } catch (Exception e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fatal!",
                            "System Error"));
        }

    }

    public void excluirCurso() {

        try {

            AreaDAO dao = new AreaDAO();

            boolean ret = dao.excluirArea(area);

            if (ret) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_INFO, "SUCESSO!",
                                "Registro excluído do banco de dados."));
            } else {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                "Erro!", "O registro não foi excluído."));
            }

            listaArea = dao.listarAreaPorNome("");

        } catch (Exception e) {

            e.printStackTrace();

            if (e.getMessage().contains("a foreign key constraint fails")) {

                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_FATAL, "Erro!",
                                "Existe um Aluno dependente desta Area!"));

            } else {

                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fatal!",
                                "System Error"));
            }

        }
    }
    public void alterarArea(RowEditEvent event) {

        try {

            AreaEntity area = (AreaEntity) event.getObject();
            AreaDAO dao = new AreaDAO();
            boolean ret = dao.alterarArea(area);

            if (ret) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_INFO, "SUCESSO!",
                                "Registro alterado no banco de dados."));
            } else {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                "Erro!", "O registro não foi alterado."));
            }

        } catch (Exception e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_FATAL,
                            "Error!", "System Error!"));

        }
    }

    public void limparForm(ActionEvent e) {
        area = new AreaEntity();
    }

}
