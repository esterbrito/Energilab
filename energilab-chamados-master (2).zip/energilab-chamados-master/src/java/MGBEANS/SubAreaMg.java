
package MGBEANS;

public class SubAreaMg {
    
}
