package MGBEANS;

import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;

@ManagedBean(name = "Historico")
public class HistorioMg {

    private List<HistoricoEntity> HistoricoBean;

    private int id;

    private int matricula;

    private Date dt_Login;

    private Date dt_loginOff;

    public HistoricoBean() {
        Historico = new HistoricoEntity();
    }

    public Date getDt_Login() {
        return dt_Login;
    }

    public void setDt_Login(Date dt_Login) {
        this.dt_Login = dt_Login;
    }

    public Date getDt_loginOff() {
        return dt_loginOff;
    }

    public void setDt_loginOff(Date dt_loginOff) {
        this.dt_loginOff= dt_loginOff;
    }

    public List<HistoricoEntity> getListaHistorico() {
        return ListaHistorico;
    }

    public void setListaAvaliacoes(List<HistoricoEntity> ListaHistorico) {
        this.ListaHistorico = ListaHistorico;
    }
}
